package com.BankHapoalimATM.contoller;

import com.BankHapoalimATM.model.Customer;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT )
class CustomerControllerIntegrationTest {

    @Autowired
    private TestRestTemplate testRestTemplate;

    @Test
    void getAllCustomers() {
    }

    @Test
    void getCustomer() {

        ResponseEntity<Customer> response = testRestTemplate.getForEntity("/customers/1",Customer.class);
        Assertions.assertEquals("1",response.getBody().getId());
        Assertions.assertEquals("Shadi",response.getBody().getFirstName());
        Assertions.assertEquals("5326-1203-8123-1111",response.getBody().getCardNumber());
        Assertions.assertEquals("1111",response.getBody().getSecreteCodeNumber());
        Assertions.assertEquals(55900,response.getBody().getBalance());
        Assertions.assertEquals("200811156",response.getBody().getIdentificationNumber());
        Assertions.assertEquals("5",response.getBody().getWithdrawalTimes());
        Assertions.assertEquals("2000",response.getBody().getWithdrawalMaxLimitAmount());

    }

    @Test
    void addCustomer() {
        Customer customer = new Customer();
        customer.setId("111");
        customer.setFirstName("Shadi");
        customer.setLastName("Sleman");
        customer.setCardNumber("5326-1203-8123-1111");
        customer.setSecreteCodeNumber("1111");
        customer.setBalance(55900);
        customer.setIdentificationNumber("200811156");
        customer.setWithdrawalTimes("5");
        customer.setWithdrawalMaxLimitAmount("2000");

        HttpEntity<Customer> request = new HttpEntity<>(customer);

        ResponseEntity<Customer> response = testRestTemplate.postForEntity("/customers", request, Customer.class);
        assertEquals(200, response.getStatusCodeValue());

    }

    @Test
    void updateCustomer() {
    }

    @Test
    void deleteCustomer() {
    }

    @Test
    void withdraw() {
    }

    @Test
    void cancelWithdraw() {
    }
}