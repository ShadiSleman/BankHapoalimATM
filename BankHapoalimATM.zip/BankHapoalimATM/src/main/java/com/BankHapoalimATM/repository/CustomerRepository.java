package com.BankHapoalimATM.repository;

import com.BankHapoalimATM.model.Customer;
import org.springframework.data.repository.CrudRepository;

public interface CustomerRepository extends CrudRepository<Customer,String > {

}
