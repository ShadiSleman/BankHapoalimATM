package com.BankHapoalimATM.schedule;


import com.BankHapoalimATM.model.Customer;
import com.BankHapoalimATM.repository.CustomerRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;

@Component
public class ScheduledProcess {

    private static final Logger LOGGER = LoggerFactory.getLogger(Customer.class);

    @Value("${withdraw.times}")
    private String withdrawTimes;

    @Value("${withdrawal.Max.Limit.Amount}")
    private String withdrawalMaxLimitAmount;


    @Autowired
    CustomerRepository customerRepository;

    @Scheduled(cron = "*/5 * * * * * ")
    public void updateMaxWithdraw() {
        List<Customer> customers = new ArrayList<>();

        customerRepository.findAll()
                .forEach(customers::add);

        for (int i = 0; i < customers.size(); i++) {
            customers.get(i).setWithdrawalTimes(withdrawTimes);
            customers.get(i).setWithdrawalMaxLimitAmount(withdrawalMaxLimitAmount);
            customerRepository.save(customers.get(i));
        }
        LOGGER.info("Data refresh every 60 seconds");
    }
}
