package com.BankHapoalimATM.model;

import lombok.Getter;
import lombok.Setter;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "Customer")
public class Customer {

    @Id
    private String id ;
    private String firstName, lastName ;
    private String cardNumber ;
    private String secreteCodeNumber ;
    private double balance ;
    private String identificationNumber;
    private String withdrawalTimes;
    private String withdrawalMaxLimitAmount;

    public Customer(){};

    public Customer(String id, String firstName, String lastName, String cardNumber, String secreteCodeNumber,double balance,String identificationNumber,String withdrawalTimes,String withdrawalMaxLimitAmount) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.cardNumber = cardNumber;
        this.secreteCodeNumber = secreteCodeNumber;
        this.balance = balance;
        this.identificationNumber=identificationNumber;
        this.withdrawalTimes=withdrawalTimes;
        this.withdrawalMaxLimitAmount=withdrawalMaxLimitAmount;
    }

}
