package com.BankHapoalimATM.contoller;

import com.BankHapoalimATM.model.Customer;
import com.BankHapoalimATM.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import java.util.List;
import java.util.Optional;

@RestController
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @RequestMapping("/customers")
    public List<Customer> getAllCustomers() {
        return customerService.getAllCustomers();
    }

    @RequestMapping("/customers/{id}")
    public Optional<Customer> getCustomer(@PathVariable String id) {
        return customerService.getCustomer(id);
    }

//    @RequestMapping(method = RequestMethod.POST, value = "/customers")
    @PostMapping(path ="/customers" , consumes = "application/json",produces = "application/json")
    public void addCustomer(@RequestBody Customer customer) {
        customerService.addCustomer(customer);
    }

    @RequestMapping(value = "/customers", method = RequestMethod.PUT)
    public void updateCustomer(@RequestParam(value = "id") String id, @RequestBody Customer customer) {
        customerService.updateCustomer(id, customer);
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/customers/{id}")
    public void deleteCustomer(@PathVariable String id) {
        customerService.deleteCustomer(id);
    }

    @RequestMapping(value = "/customers/withdraw", method = RequestMethod.PUT)
    public ResponseEntity<Customer> withdraw(@RequestParam String cardNumber, @RequestParam String secreteCodeNumber, @RequestParam double amount) {
        boolean withdrawalResult = customerService.withdrow(cardNumber, secreteCodeNumber, amount);
        if (withdrawalResult) {
            return new ResponseEntity<Customer>(HttpStatus.OK);
        } else {
            String url = "http://localhost:8080/customers/cancel-withdraw";
            RestTemplate restTemplate = new RestTemplate();

            // Query parameters
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url)
                    // Add query parameter
                    .queryParam("cardNumber", cardNumber)
                    .queryParam("secreteCodeNumber", secreteCodeNumber)
                            .queryParam("amount", amount);

            restTemplate.put(builder.build().toUri(), null);
            return new ResponseEntity<Customer>(HttpStatus.NOT_ACCEPTABLE);
        }
    }

    @RequestMapping(value = "/customers/cancel-withdraw", method = RequestMethod.PUT)
    public ResponseEntity<Customer> cancelWithdraw(@RequestParam String cardNumber, @RequestParam String secreteCodeNumber, @RequestParam double amount) {
        boolean withdrawalResult = customerService.cancelWithdraw(cardNumber, secreteCodeNumber, amount);
        if (withdrawalResult) {
            return new ResponseEntity<Customer>(HttpStatus.OK);
        } else {
            return new ResponseEntity<Customer>(HttpStatus.NOT_ACCEPTABLE);
        }
    }
}