package com.BankHapoalimATM.service;

import com.BankHapoalimATM.model.Customer;
import com.BankHapoalimATM.repository.CustomerRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {

    private static final Logger LOGGER = LoggerFactory.getLogger(Customer.class);

    @Autowired
    private CustomerRepository customerRepository;

    public List<Customer> getAllCustomers() {
        List<Customer> customers = new ArrayList<>();

        customerRepository.findAll()
                .forEach(customers::add);
        LOGGER.info("getAllCustomers service");
        return customers;
    }

    public Optional<Customer> getCustomer(String id) {
        LOGGER.info("getCustomer service");
        return customerRepository.findById(id);
    }

    public void addCustomer(Customer customer) {
        LOGGER.info("addCustomer service");
        customerRepository.save(customer);
    }

    public void updateCustomer(String id, Customer customer) {
        LOGGER.info("updateCustomer service");
        customerRepository.save(customer);
    }

    public void deleteCustomer(String id) {
        LOGGER.info("deleteCustomer service");
        customerRepository.deleteById(id);
    }

    @Transactional
    public boolean cancelWithdraw(String cardNumber, String secreteCodeNumber, double amount) {
        LOGGER.info("Need to cancel the withdrawal");
        return true;
    }

    @Transactional
    public boolean withdrow(String cardNumber, String secreteCodeNumber, double amount) {
        List<Customer> customers = new ArrayList<>();
        customerRepository.findAll().forEach(customers::add);
        for (int i = 0; i < customers.size(); i++) {
            if (cardNumber.equals(customers.get(i).getCardNumber()) &&
                    secreteCodeNumber.equals(customers.get(i).getSecreteCodeNumber()) ) {
                Optional<Customer> myCustomer = customerRepository.findById(customers.get(i).getId());
                if (isWithdrawable(myCustomer,amount)) {
                    double oldBalance = myCustomer.get().getBalance();
                    myCustomer.get().setBalance(oldBalance - amount);

                    double oldWithdrawableTimes = Double.parseDouble(myCustomer.get().getWithdrawalTimes());
                    double newWithdrawableTimes = oldWithdrawableTimes - 1;

                    double oldWithdrawalMaxLimitAmount = Double.parseDouble(myCustomer.get().getWithdrawalMaxLimitAmount());
                    double newWithdrawalMaxLimitAmount = oldWithdrawalMaxLimitAmount - amount;

                    myCustomer.get().setWithdrawalTimes(String.valueOf(newWithdrawableTimes));
                    myCustomer.get().setWithdrawalMaxLimitAmount(String.valueOf(newWithdrawalMaxLimitAmount));
                    customerRepository.save(myCustomer.get());
                    LOGGER.info("withdrawal has been successfully");
                    return true;
                }
            }
        }
        LOGGER.info("withdrawal has been rejected");
        return false;
    }


    public boolean isWithdrawable(Optional<Customer> myCustomer,double amount) {
        if (Double.parseDouble(myCustomer.get().getWithdrawalTimes()) > 0 &&
                Double.parseDouble(myCustomer.get().getWithdrawalMaxLimitAmount()) >= amount)
            return true;
        else return false;
    }

}
