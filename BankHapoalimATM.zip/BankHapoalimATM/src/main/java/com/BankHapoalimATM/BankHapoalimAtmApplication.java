package com.BankHapoalimATM;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@SpringBootApplication
public class BankHapoalimAtmApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(BankHapoalimAtmApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(BankHapoalimAtmApplication.class, args);

		LOGGER.info("BankHapoalim ATM Started  ");

	}

}
